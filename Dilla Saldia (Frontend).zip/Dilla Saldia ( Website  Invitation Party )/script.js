function whatsapp2(name,){
  const message = `${name}`
  const whatsapp = `https://wa.me/6282123437618?text=${message}`
  open(whatsapp, "_blank")
}

function scrollr(){
  var left=document.querySelector(".scroll-img");
  left.scrollBy(350,0)
}

function scrolll(){
  var right=document.querySelector(".scroll-img");
  right.scrollBy(-350,0)
}